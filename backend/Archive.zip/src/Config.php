<?php
declare(strict_types=1);

/** Reads backend/config.php once. Config::get('db.host') walks the nested arrays. */
final class Config
{
    private static ?array $data = null;

    public static function get(string $path, mixed $default = null): mixed
    {
        if (self::$data === null) {
            $file = dirname(__DIR__) . '/config.php';
            if (!is_file($file)) {
                throw new RuntimeException('config.php is missing. Copy config.sample.php to config.php and fill it in.');
            }
            self::$data = require $file;
        }
        $v = self::$data;
        foreach (explode('.', $path) as $part) {
            if (!is_array($v) || !array_key_exists($part, $v)) return $default;
            $v = $v[$part];
        }
        return $v;
    }

    public static function debug(): bool
    {
        try { return (bool) self::get('debug', false); } catch (Throwable) { return false; }
    }
}
